import { AsyncLocalStorage } from 'node:async_hooks'
import { randomUUID } from 'node:crypto'
import { mkdir, realpath, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { readPassageConfig } from '../apps/site-api/src/research-passages/config'
import { PassageError } from '../apps/site-api/src/research-passages/release'
import { createPassageRoutes } from '../apps/site-api/src/research-passages/routes'
import type { StageProvider } from '../apps/site-api/src/research-passages/types'

const privateRoot = path.resolve(import.meta.dir)
const safeError = (error: unknown) => error instanceof PassageError ? error.code : 'provider_failure'

/** Only a direct child of this ignored private directory may receive traces. */
export async function prepareTraceDirectory(value = path.join(privateRoot, 'passage-stage-traces')) {
  if (value.includes('\0') || path.win32.parse(value.replaceAll('/', '\\')).root.startsWith('\\\\')) throw new Error('Invalid private trace directory.')
  const directory = path.resolve(value)
  if (path.dirname(directory) !== privateRoot) throw new Error('Trace directory must be a direct .superpowers child.')
  const root = await realpath(privateRoot)
  const current = await stat(directory).catch(error => { if (error.code === 'ENOENT') return null; throw error })
  if (!current) await mkdir(directory)
  else if (!current.isDirectory()) throw new Error('Trace output must be a directory.')
  const resolved = await realpath(directory)
  if (path.dirname(resolved) !== root) throw new Error('Trace directory escapes the private root.')
  // A unique retained probe proves write access before any answering can start.
  await writeFile(path.join(resolved, `${randomUUID()}.probe.json`), `${JSON.stringify({ event: 'write_probe', at: new Date().toISOString() })}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
  return resolved
}

/** Preserves provider arguments, returned values, exceptions and attempt count. */
export async function createTracedProvider(original: StageProvider, outputDirectory?: string) {
  const directory = await prepareTraceDirectory(outputDirectory)
  const context = new AsyncLocalStorage<{ request_id: string; stage_index: number }>()
  const persist = async (filename: string, value: unknown) => writeFile(path.join(directory, filename), `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
  const provider: StageProvider = {
    mode: original.mode, model: original.model, stageProfiles: original.stageProfiles,
    preflight: (stage, input) => original.preflight(stage, input),
    available: () => original.available(), limits: () => original.limits(),
    async invoke(stage, input, signal) {
      const request = context.getStore() ?? { request_id: randomUUID(), stage_index: 0 }
      const stageIndex = ++request.stage_index
      const eventId = `${request.request_id}-${stageIndex}-${stage}-${randomUUID()}`
      const base = { request_id: request.request_id, stage_index: stageIndex, stage, started_at: new Date().toISOString(), before_limits: original.limits() }
      // No request headers, environment values, provider options or raw errors.
      // Failure to record before invocation prevents a new untraced attempt.
      try { await persist(`${eventId}.started.json`, { ...base, input }) }
      catch { throw new PassageError('provider_failure') }
      let result: unknown, caught: unknown, failed = false
      try { result = await original.invoke(stage, input, signal) }
      catch (error) { caught = error; failed = true }
      try {
        await persist(`${eventId}.completed.json`, { ...base, finished_at: new Date().toISOString(), after_limits: original.limits(), ...(failed ? { error: safeError(caught) } : { parsed: result }) })
      } catch {
        // Preserve an original provider exception. For a successful provider
        // call, fail closed if its diagnostic result could not be retained.
        if (!failed) throw new PassageError('provider_failure')
        console.error(JSON.stringify({ event: 'private_trace_write_failed', request_id: request.request_id, stage }))
      }
      if (failed) throw caught
      return result
    },
  }
  const runRequest = <T>(callback: () => T): T => context.run({ request_id: randomUUID(), stage_index: 0 }, callback)
  return { provider, directory, runRequest }
}

async function start() {
  const config = readPassageConfig(Bun.env)
  const traced = await createTracedProvider(config.provider, Bun.env.RESEARCH_TRACE_DIRECTORY)
  const app = createPassageRoutes({ ...config, provider: traced.provider })
  // Stay above the passage service's 150-second complete-answer deadline.
  Bun.serve({ hostname: '127.0.0.1', port: config.port, maxRequestBodySize: 16_384, idleTimeout: 160, fetch: request => traced.runRequest(() => app.handle(request)) })
  console.info(JSON.stringify({ service: 'private-traced-research', port: config.port, trace_directory: traced.directory }))
}

if (import.meta.main) {
  if (process.argv.includes('--check')) console.log(JSON.stringify({ imports: 'ok', model_calls: 0, server_started: false }))
  else start().catch(() => { console.error(JSON.stringify({ error: 'private_trace_startup_failed' })); process.exitCode = 1 })
}
